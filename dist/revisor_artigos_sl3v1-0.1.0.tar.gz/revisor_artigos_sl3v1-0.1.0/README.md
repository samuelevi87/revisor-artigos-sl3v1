# RevisorArtigosSl3V1 Crew

Bem-vindo ao projeto RevisorArtigosSl3V1 Crew, desenvolvido com o [crewAI](https://crewai.com). Este template foi criado para ajudá-lo a configurar um sistema de IA multiagente de forma fácil, aproveitando o poderoso e flexível framework fornecido pelo crewAI. Nosso objetivo é permitir que seus agentes colaborem de maneira eficaz em tarefas complexas, maximizando sua inteligência coletiva e capacidades.

## Instalação

Certifique-se de ter o Python >=3.10 <=3.13 instalado no seu sistema. Este projeto usa o [UV](https://docs.astral.sh/uv/) para gerenciamento de dependências e pacotes, oferecendo uma experiência de configuração e execução tranquila.

Primeiro, se ainda não o fez, instale o **uv**:

```bash
pip install uv
```

Em seguida, navegue até o diretório do seu projeto e instale as dependências:

(Opcional) Trave as dependências e instale-as usando o comando na linha de comando:
```bash
crewai install
```

### Personalização

**Adicione sua `OPENAI_API_KEY` no arquivo `.env`**

- Modifique `src/revisor_artigos_sl3v1/config/agents.yaml` para definir seus agentes.
- Modifique `src/revisor_artigos_sl3v1/config/tasks.yaml` para definir suas tarefas.
- Modifique `src/revisor_artigos_sl3v1/crew.py` para adicionar sua própria lógica, ferramentas e argumentos específicos.
- Modifique `src/revisor_artigos_sl3v1/main.py` para adicionar entradas personalizadas para seus agentes e tarefas.

## Executando o Projeto

Para iniciar sua equipe de agentes de IA e começar a execução das tarefas, execute o seguinte comando na pasta raiz do projeto:

```bash
$ crewai run
```

Este comando inicializa a equipe RevisorArtigosSl3V1 Crew, montando os agentes e atribuindo-lhes as tarefas definidas em sua configuração.

Este exemplo, sem modificações, irá criar um arquivo `report.md` com o resultado de uma pesquisa sobre LLMs na pasta raiz.

## Compreendendo Sua Equipe

A equipe RevisorArtigosSl3V1 Crew é composta por múltiplos agentes de IA, cada um com papéis, objetivos e ferramentas únicos. Esses agentes colaboram em uma série de tarefas, definidas em `config/tasks.yaml`, aproveitando suas habilidades coletivas para alcançar objetivos complexos. O arquivo `config/agents.yaml` descreve as capacidades e configurações de cada agente em sua equipe.

## Suporte

Para suporte, perguntas ou feedback sobre o RevisorArtigosSl3V1 Crew ou crewAI:
- Visite nossa [documentação](https://docs.crewai.com)
- Entre em contato através do nosso [repositório no GitHub](https://github.com/joaomdmoura/crewai)
- [Junte-se ao nosso Discord](https://discord.com/invite/X4JWnZnxPb)
- [Converse com nossa documentação](https://chatg.pt/DWjSBZn)

Vamos criar maravilhas juntos com o poder e a simplicidade do crewAI.